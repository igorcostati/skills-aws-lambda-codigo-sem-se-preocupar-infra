export function log(mensagem, evento){
    console.log(mensagem, evento);
}